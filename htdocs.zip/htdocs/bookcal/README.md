# BOOKCAL FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

## Features

Provide features to be able to record online booking.

<!--
![Screenshot bookcal](img/screenshot_bookcal.png?raw=true "BookCal"){imgmd}
-->
